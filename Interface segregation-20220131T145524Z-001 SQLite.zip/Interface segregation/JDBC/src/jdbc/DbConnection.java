/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author BSE173029
 */
public class DbConnection {
    Connection MyConnection;

    public DbConnection() {
        try {
            MyConnection=DriverManager.getConnection("jdbc:mysql://localhost:3306/store","root","");
        } catch (SQLException ex) {
            Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void add(String query){
        int rows=0;
        try {
            Statement stmt=MyConnection.createStatement();
            rows=stmt.executeUpdate(query);
            System.out.println(rows + "row(s) affected!!!");
                    } catch (SQLException ex) {
            Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void updateRecord(String query){
        int rows=0;
        try {
            Statement stmt=MyConnection.createStatement();
            rows=stmt.executeUpdate(query);
            System.out.println("record updated with affected row (s)!!!"+rows );
        } catch (SQLException ex) {
            Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
 
   