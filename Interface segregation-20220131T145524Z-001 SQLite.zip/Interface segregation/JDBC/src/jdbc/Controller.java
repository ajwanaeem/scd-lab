/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

/**
 *
 * @author BSE173029
 */
public class Controller {
    DbConnection connection;
    Product pro;
    
    public Controller(String n, String d, int p){
        pro=new Product(n,d,p);
        connection=new DbConnection();
    }
    public void insertRecord(){
        String query="Insert into Product(name, description, price) values"+
                "('"+pro.getName()+"','"+pro.getDescription()+"','"+pro.getPrice()+"')";
        
        connection.add(query);
    }
    
    public void updateRecord(){
        connection.updateRecord("update product set name='"+pro.name+"',description='"+
                pro.Description+"',"+"price='"+pro.price+"'where id='"+2+"'");
    }
}
