/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

/**
 *
 * @author bse173029
 */
public class FileStorage implements IStorage{

    
    @Override
    public void insertData() {
         //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updateData() {
        //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteData() {
       //To change body of generated methods, choose Tools | Templates.
    }
    
}
