/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

/**
 *
 * @author BSE173029
 */
public class Product {
    int id;
    String name;
    String Description;
    int price;

    public Product() {
    }

    public Product(String name, String Description, int Price){
        this.name=name;
        this.Description=Description;
        this.price=Price;
    }
    public Product(int id, String name, String Description, int price) {
        this.id = id;
        this.name = name;
        this.Description = Description;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    
    
    
}
