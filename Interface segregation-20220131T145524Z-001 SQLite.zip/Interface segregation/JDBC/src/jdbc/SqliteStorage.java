/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author bse173029
 */
public class SqliteStorage implements IStorage, IConnection {
    Connection con;
    Product pro;
    
    public SqliteStorage(String n,  String d,int p){
        pro=new Product(n,d,p);
    }

    SqliteStorage() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void DbConnection() {
       try {
           Class.forName("org.sqlite.JDBC");
            con=DriverManager.getConnection("jdbc:sqlite:store.db");
        } catch (Exception ex) {
            Logger.getLogger(SqlStorage.class.getName()).log(Level.SEVERE, null, ex);
        } //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void insertData() {
           String query="Insert into Product(name, description, price) values"+
                "('"+pro.getName()+"','"+pro.getDescription()+"','"+pro.getPrice()+"')";
            int rows=0;
        try {
            Statement stmt=con.createStatement();
            rows=stmt.executeUpdate(query);
            System.out.println(rows + "row(s) affected!!!");
                    } catch (SQLException ex) {
            Logger.getLogger(SqlStorage.class.getName()).log(Level.SEVERE, null, ex);
        }//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updateData() {
         String query="UPDATE product SET name='"+pro.getName()+"',description='"+pro.getDescription()
                 +"',price='"+pro.getPrice()+"' WHERE id='"+2+"'";
   
         int rows=0;
          try {
            Statement stmt=con.createStatement();
            rows=stmt.executeUpdate(query);
            System.out.println("record updated with affected row (s)!!!"+rows );
        } catch (SQLException ex) {
            Logger.getLogger(SqlStorage.class.getName()).log(Level.SEVERE, null, ex);
        }//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteData() {
       
        Statement stmt;
        String query="Delete from product where id='"+2+"'";
        try {
            stmt = con.createStatement();
            int rows=stmt.executeUpdate(query);
            System.out.println("Record deleted successfully!!!!");
            
        } catch (SQLException ex) {
            Logger.getLogger(SqlStorage.class.getName()).log(Level.SEVERE, null, ex);
        }



//To change body of generated methods, choose Tools | Templates.
    }
}
